
import React, { useState, useEffect } from 'react';
import SettingsIcon from './icons/SettingsIcon';
import CheckCircleIcon from './icons/CheckCircleIcon';

const Settings: React.FC = () => {
    const [printifyApiKey, setPrintifyApiKey] = useState('');
    const [saveStatus, setSaveStatus] = useState<'idle' | 'success'>('idle');

    useEffect(() => {
        const savedPrintifyKey = localStorage.getItem('printifyApiKey');
        if (savedPrintifyKey) {
            setPrintifyApiKey(savedPrintifyKey);
        }
    }, []);

    const handleSave = () => {
        localStorage.setItem('printifyApiKey', printifyApiKey);
        setSaveStatus('success');
        setTimeout(() => setSaveStatus('idle'), 2000);
    };

    return (
        <div className="max-w-2xl mx-auto space-y-8">
            <div className="flex items-center space-x-4">
                <SettingsIcon className="h-10 w-10 text-brand-primary" />
                <h1 className="text-3xl font-bold text-white">Settings</h1>
            </div>

            <div className="bg-slate-800 p-6 rounded-lg space-y-6">
                <div>
                    <h2 className="text-xl font-semibold text-white">API Keys</h2>
                    <p className="text-slate-400 mt-1">Your keys are stored securely in your browser's local storage and are never sent to our servers.</p>
                </div>

                <div className="space-y-4">
                    {/* FIX: Removed Google AI API Key input to enforce usage of environment variables as per guidelines. */}
                    <div>
                        <label htmlFor="printifyApiKey" className="block text-sm font-medium text-slate-300 mb-1">
                            Printify API Key
                        </label>
                        <input
                            type="password"
                            id="printifyApiKey"
                            value={printifyApiKey}
                            onChange={(e) => setPrintifyApiKey(e.target.value)}
                            placeholder="Enter your Printify API Key"
                            className="w-full bg-slate-700 border border-slate-600 rounded-md px-3 py-2 focus:ring-brand-primary focus:outline-none"
                        />
                    </div>
                </div>

                <div className="flex justify-end items-center">
                    {saveStatus === 'success' && (
                        <div className="flex items-center text-green-400 mr-4">
                            <CheckCircleIcon />
                            <span className="ml-2">Settings saved!</span>
                        </div>
                    )}
                    <button
                        onClick={handleSave}
                        className="bg-brand-primary hover:bg-brand-secondary text-white font-bold py-2 px-6 rounded-md transition-colors duration-200"
                    >
                        Save Settings
                    </button>
                </div>
            </div>
        </div>
    );
};

export default Settings;
